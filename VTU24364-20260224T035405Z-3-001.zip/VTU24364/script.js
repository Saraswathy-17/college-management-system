const form = document.getElementById("teacherForm");
const table = document.getElementById("teacherTable");
const status = document.getElementById("status");
const search = document.getElementById("search");

let teachers = JSON.parse(localStorage.getItem("teachers")) || [];
let editId = null;

// ===== RENDER =====
const render = () => {
    table.innerHTML = "";
    teachers.forEach(t => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${t.id}</td>
            <td>${t.name}</td>
            <td>${t.age}</td>
            <td>${t.yoe}</td>
            <td>${t.doj}</td>
            <td>${t.salary}</td>
        `;

        // click
        row.addEventListener("click", () => {
            document.querySelectorAll("tr").forEach(r => r.classList.remove("selected"));
            row.classList.add("selected");
        });

        // double click → edit
        row.addEventListener("dblclick", () => loadForEdit(t));

        table.appendChild(row);
    });
};

// ===== LOAD FOR EDIT =====
const loadForEdit = ({ id, name, age, yoe, doj, salary }) => {
    editId = id;
    tid.value = id;
    tname.value = name;
    tage.value = age;
    tyoe.value = yoe;
    tdoj.value = doj;
    tsalary.value = salary;
};

// ===== FORM SUBMIT =====
form.addEventListener("submit", e => {
    e.preventDefault();

    if (!tid.value || !tname.value) {
        status.style.color = "red";
        status.textContent = "ID and Name are required";
        return;
    }

    const teacher = {
        id: tid.value,
        name: tname.value,
        age: tage.value,
        yoe: tyoe.value,
        doj: tdoj.value,
        salary: tsalary.value
    };

    if (editId) {
        teachers = teachers.map(t => t.id === editId ? teacher : t);
        editId = null;
        console.log("Teacher updated");
    } else {
        teachers.push(teacher);
        console.log("Teacher added");
    }

    localStorage.setItem("teachers", JSON.stringify(teachers));
    form.reset();
    status.style.color = "green";
    status.textContent = "Saved successfully";
    render();
});

// ===== KEYBOARD SHORTCUT =====
document.addEventListener("keydown", e => {
    if (e.ctrlKey && e.key === "Enter") {
        form.requestSubmit();
    }
});

// ===== SEARCH =====
search.addEventListener("input", () => {
    const value = search.value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(value)
            ? "" : "none";
    });
});

// ===== INIT =====
render();
console.log("Professional Teacher Management Loaded");
