// State management
let products = [];
let cart = [];
let currentFilter = 'All';

// Locales formatting (INR)
const formatINR = (value) => {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    }).format(value);
};

// DOM Elements
const productGrid = document.getElementById('product-grid');
const cartCount = document.getElementById('cart-count');
const cartOverlay = document.getElementById('cart-overlay');
const cartBtn = document.getElementById('cart-btn');
const closeCartBtn = document.getElementById('close-cart-btn');
const cartItemsContainer = document.getElementById('cart-items-container');
const cartTotalPrice = document.getElementById('cart-total-price');
const toastEl = document.getElementById('toast');
const toastMsg = document.getElementById('toast-msg');

// Modal Elements
const productModal = document.getElementById('product-modal');
const closeModalBtn = document.getElementById('close-modal-btn');
const modalLayout = document.getElementById('modal-layout');
const filterBtns = document.querySelectorAll('.filter-btn');

// Checkout Elements
const checkoutBtn = document.getElementById('checkout-btn');
const checkoutModal = document.getElementById('checkout-modal');
const closeCheckoutBtn = document.getElementById('close-checkout-btn');
const checkoutForm = document.getElementById('checkout-form');

const API_BASE = '/ecommerce';

// Auth & Search Elements
const searchInput = document.getElementById('search-input');
const accountBtn = document.getElementById('account-btn');
const accountName = document.getElementById('account-name');

let currentUser = null;

// Initialization
document.addEventListener('DOMContentLoaded', async () => {
    await checkAuth();
    if (document.getElementById('product-grid')) {
        await fetchProducts();
        await fetchCart();
    }
    setupEventListeners();
});

// APIs
async function checkAuth() {
    try {
        const res = await fetch(`${API_BASE}/api.php?endpoint=auth&action=me`);
        const result = await res.json();
        if(result.success) {
            currentUser = result.user;
            if(accountName) accountName.innerText = currentUser.username;
        } else {
            currentUser = null;
            if(accountName) accountName.innerText = "Login";
        }
    } catch (e) { console.error(e); }
}
async function fetchProducts() {
    try {
        const res = await fetch(`${API_BASE}/api.php?endpoint=products`);
        const result = await res.json();
        if(result.success) {
            products = result.data;
            renderProducts();
        } else {
            console.error(result.error);
            alert("Database Error! Did you run setup.php?");
        }
    } catch (e) {
        console.error("Products error", e);
    }
}

async function fetchCart() {
    try {
        const res = await fetch(`${API_BASE}/api.php?endpoint=cart`);
        const result = await res.json();
        if(result.success) {
            cart = result.data;
            updateCartUI();
        }
    } catch (e) { console.error("Cart error", e); }
}

async function updateCartAPI(productId, qtyChange) {
    try {
        await fetch(`${API_BASE}/api.php?endpoint=cart`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId, quantity: qtyChange })
        });
        await fetchCart();
    } catch (e) { console.error(e); }
}

// Rendering
function renderStars(avg, count, productId, interactive = false) {
    const rounded = Math.round(avg);
    const stars = [1,2,3,4,5].map(i => {
        const filled = i <= rounded;
        if (interactive) {
            return `<span class="star ${filled ? 'filled' : ''}" data-val="${i}" onclick="submitRating(${productId}, ${i})">&#9733;</span>`;
        }
        return `<span class="star ${filled ? 'filled' : ''}">&#9733;</span>`;
    }).join('');
    const cls = interactive ? 'star-row interactive' : 'star-row';
    const html = `<div class="${cls}" id="stars-${productId}">${stars}<span class="star-count">(${count})</span></div>`;
    return html;
}

function attachStarHover(productId) {
    const row = document.getElementById(`stars-${productId}`);
    if (!row || !row.classList.contains('interactive')) return;
    const stars = row.querySelectorAll('.star');
    stars.forEach((star, idx) => {
        star.addEventListener('mouseenter', () => {
            stars.forEach((s, j) => {
                if (j <= idx) { s.classList.add('hovered'); }
                else { s.classList.remove('hovered'); }
            });
        });
        star.addEventListener('mouseleave', () => {
            stars.forEach(s => s.classList.remove('hovered'));
        });
    });
    row.addEventListener('mouseleave', () => {
        stars.forEach(s => s.classList.remove('hovered'));
    });
}

async function fetchRating(productId) {
    try {
        const res = await fetch(`${API_BASE}/api.php?endpoint=ratings&product_id=${productId}`);
        const r = await res.json();
        return r.success ? r : { avg: 0, count: 0 };
    } catch(e) { return { avg: 0, count: 0 }; }
}

async function submitRating(productId, rating) {
    try {
        const res = await fetch(`${API_BASE}/api.php?endpoint=ratings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId, rating })
        });
        const r = await res.json();
        if (r.success) {
            const ratingEl = document.getElementById(`rating-modal-${productId}`);
            if (ratingEl) ratingEl.innerHTML = renderStars(r.avg, r.count, productId, true);
            attachStarHover(productId);
            showToast('Rating submitted!');
        }
    } catch(e) { console.error(e); }
}

function renderProducts() {
    productGrid.innerHTML = '';
    
    // Filter logic Category
    let filtered = currentFilter === 'All' 
        ? products 
        : products.filter(p => p.category === currentFilter);
        
    // Filter logic Search
    const query = searchInput.value.toLowerCase();
    if (query) {
        filtered = filtered.filter(p => p.name.toLowerCase().includes(query) || p.description.toLowerCase().includes(query));
    }
        
    if(filtered.length === 0) {
        productGrid.innerHTML = '<p style="text-align:center;color:#888;grid-column:1/-1;">No products found.</p>';
        return;
    }

    filtered.forEach(async p => {
        const pPrice = formatINR(p.price);
        const card = document.createElement('div');
        card.className = 'product-card';
        card.innerHTML = `
            <div class="img-wrapper" onclick="openProductModal(${p.id})">
                <img src="${p.image_url}" alt="${p.name}">
            </div>
            <div class="product-info">
                <div class="product-category">${p.category}</div>
                <h3 class="product-title" onclick="openProductModal(${p.id})">${p.name}</h3>
                <div id="rating-card-${p.id}" class="star-row"><span class="star-count">Loading...</span></div>
                <div class="product-price">${pPrice}</div>
                <div class="card-actions">
                    <button class="view-btn" onclick="openProductModal(${p.id})">Details</button>
                    <button class="add-btn" onclick="addToCart(${p.id}, '${p.name.replace(/'/g, "\\'")}')">Add to Cart</button>
                </div>
            </div>
        `;
        productGrid.appendChild(card);
        const rData = await fetchRating(p.id);
        const rEl = document.getElementById(`rating-card-${p.id}`);
        if (rEl) rEl.outerHTML = renderStars(rData.avg, rData.count, p.id, false);
    });
}

function updateCartUI() {
    const count = cart.reduce((acc, item) => acc + parseInt(item.quantity), 0);
    cartCount.innerText = count;

    cartItemsContainer.innerHTML = '';
    let total = 0;
    
    if(cart.length === 0) {
        cartItemsContainer.innerHTML = '<p style="color:var(--text-secondary);text-align:center;margin-top:2rem;">Your cart is empty.</p>';
    }

    cart.forEach(item => {
        const price = parseFloat(item.price);
        const qty = parseInt(item.quantity);
        total += price * qty;
        
        const el = document.createElement('div');
        el.className = 'cart-item';
        el.innerHTML = `
            <img src="${item.image_url}" class="cart-item-img" alt="${item.name}">
            <div class="cart-item-info">
                <div class="cart-item-title">${item.name}</div>
                <div class="cart-item-price">${formatINR(price)}</div>
                <div class="qty-controls">
                    <button onclick="changeQuantity(${item.product_id}, -1)">-</button>
                    <span>${qty}</span>
                    <button onclick="changeQuantity(${item.product_id}, 1)">+</button>
                </div>
            </div>
        `;
        cartItemsContainer.appendChild(el);
    });

    cartTotalPrice.innerText = formatINR(total);
}

// Actions
async function addToCart(productId, name) {
    showToast(`${name} added to cart`);
    await updateCartAPI(productId, 1);
}

async function changeQuantity(productId, change) {
    await updateCartAPI(productId, change);
}

async function openProductModal(id) {
    const p = products.find(prod => prod.id == id);
    if(!p) return;
    const rData = await fetchRating(p.id);
    modalLayout.innerHTML = `
        <img src="${p.image_url}" alt="${p.name}" class="modal-image">
        <div class="modal-details">
            <div class="modal-tag">${p.category}</div>
            <h2 class="modal-title">${p.name}</h2>
            <div class="modal-price">${formatINR(p.price)}</div>
            <div id="rating-modal-${p.id}">${renderStars(rData.avg, rData.count, p.id, true)}</div>
            <p class="modal-rating-hint">Click a star to rate this product</p>
            <p class="modal-desc">${p.description}</p>
            <div class="modal-actions">
                <button class="modal-add" onclick="addToCart(${p.id}, '${p.name.replace(/'/g, "\\'")}')">Add to Cart</button>
            </div>
        </div>
    `;
    productModal.classList.add('active');
    attachStarHover(p.id);
}

// Nav Interactions
window.addEventListener('scroll', () => {
    const header = document.getElementById('main-header');
    if(window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// Event Listeners
function setupEventListeners() {
    if (!cartBtn) return;
    cartBtn.addEventListener('click', () => { cartOverlay.classList.add('active'); });
    closeCartBtn.addEventListener('click', () => { cartOverlay.classList.remove('active'); });
    cartOverlay.addEventListener('click', (e) => {
        if(e.target === cartOverlay) cartOverlay.classList.remove('active');
    });

    closeModalBtn.addEventListener('click', () => { productModal.classList.remove('active'); });
    productModal.addEventListener('click', (e) => {
        if(e.target === productModal) productModal.classList.remove('active');
    });

    // Checkout Modal Logic
    checkoutBtn.addEventListener('click', () => {
        if(cart.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        checkoutModal.classList.add('active');
    });
    
    closeCheckoutBtn.addEventListener('click', () => {
        checkoutModal.classList.remove('active');
    });

    checkoutForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = checkoutForm.querySelector('button');

        const cardNumber = document.getElementById('chk-card-number').value.replace(/\s/g, '');
        const expiry = document.getElementById('chk-card-expiry').value;
        const cvv = document.getElementById('chk-card-cvv').value;

        if (cardNumber.length < 13 || cardNumber.length > 16) {
            alert('Please enter a valid card number.');
            return;
        }
        const [expMonth, expYear] = expiry.split('/');
        const now = new Date();
        const fullYear = 2000 + parseInt(expYear || '0');
        if (!expMonth || !expYear || parseInt(expMonth) < 1 || parseInt(expMonth) > 12 ||
            fullYear < now.getFullYear() || (fullYear === now.getFullYear() && parseInt(expMonth) < now.getMonth() + 1)) {
            alert('Please enter a valid expiry date.');
            return;
        }
        if (cvv.length < 3) {
            alert('Please enter a valid CVV.');
            return;
        }

        btn.innerText = "Processing...";
        btn.disabled = true;

        const payload = {
            name: document.getElementById('chk-name').value,
            email: document.getElementById('chk-email').value,
            address: document.getElementById('chk-address').value,
            payment_method: 'Credit/Debit Card'
        };

        try {
            const res = await fetch(`${API_BASE}/api.php?endpoint=checkout`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await res.json();
            
            if(result.success) {
                alert(`Order Successful! Order ID: #${result.order_id}\n\nYour order has been confirmed and payment processed successfully.`);
                checkoutModal.classList.remove('active');
                cartOverlay.classList.remove('active');
                checkoutForm.reset();
                await fetchCart(); // will be empty now
            } else {
                alert("Checkout failed: " + result.error);
            }
        } catch(err) {
            console.error(err);
            alert("Checkout Error");
        } finally {
            btn.innerText = "Pay & Finalize Order";
            btn.disabled = false;
        }
    });
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterBtns.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            currentFilter = e.target.dataset.filter;
            renderProducts();
        });
    });
    // Search logic
    searchInput.addEventListener('input', () => {
        renderProducts();
    });

    // Auth redirection
    accountBtn.addEventListener('click', () => {
        window.location.href = 'auth.html';
    });
}

function showToast(msg) {
    toastMsg.innerText = msg;
    toastEl.classList.add('show');
    setTimeout(() => { toastEl.classList.remove('show'); }, 3000);
}
