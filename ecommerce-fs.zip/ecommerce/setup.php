<?php
require_once 'db.php';

try {
    $pdo = getDbConnection();
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS ecommerce_db");
    $pdo->exec("USE ecommerce_db");
    
    // Reset Everything to apply new changes
    $pdo->exec("DROP TABLE IF EXISTS order_items");
    $pdo->exec("DROP TABLE IF EXISTS orders");
    $pdo->exec("DROP TABLE IF EXISTS cart_items");
    $pdo->exec("DROP TABLE IF EXISTS ratings");
    $pdo->exec("DROP TABLE IF EXISTS products");
    $pdo->exec("DROP TABLE IF EXISTS users");
    
    // Create users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Create products table
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        image_url TEXT,
        category VARCHAR(100) DEFAULT 'Electronics'
    )");
    
    // Create cart table
    $pdo->exec("CREATE TABLE IF NOT EXISTS cart_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_id VARCHAR(100) NOT NULL,
        product_id INT NOT NULL,
        quantity INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY session_product (session_id, product_id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");

    // Create orders table
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        customer_name VARCHAR(255) NOT NULL,
        customer_email VARCHAR(255) NOT NULL,
        customer_address TEXT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        payment_method VARCHAR(50) DEFAULT 'Credit Card',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Create order_items table
    $pdo->exec("CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    
    // Create ratings table
    $pdo->exec("CREATE TABLE IF NOT EXISTS ratings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        session_id VARCHAR(100) NOT NULL,
        rating TINYINT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY session_product_rating (session_id, product_id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");

    // Insert modern products with working images
    $products = [
        ['Aura Noise Cancelling Pro', 'Experience industry-leading noise cancellation. Features up to 30 hours of battery life, intuitive touch controls, and high-resolution audio.', 24999.00, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80', 'Audio'],
        ['Aura Smart Watch Series X', 'Track your health and fitness with precision. Includes real-time heart rate monitoring, blood oxygen sensors, built-in GPS, and an Always-On Retina display.', 34999.00, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80', 'Wearables'],
        ['Classic Film Camera 35mm', 'A meticulously restored vintage 35mm film camera. Delivers pure analog photography experience with a precision manual focus lens.', 45500.00, 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=800&q=80', 'Photography'],
        ['Aviator Polarized Sunglasses', 'Premium polarized sunglasses featuring a lightweight titanium frame, 100% UV protection, and glare reduction. Designed for maximum visual comfort.', 8500.00, 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80', 'Accessories'],
        ['Hand-stitched Leather Wallet', 'Crafted from full-grain Italian leather, this minimalist bi-fold wallet features 6 card slots, a cash compartment, and RFID-blocking hardware.', 3500.00, 'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=80', 'Accessories'],
        ['Mechanical Keyboard Pro', 'A professional-grade mechanical keyboard featuring tactile Cherry MX switches, customizable RGB backlighting, aircraft-grade aluminum frame.', 12999.00, 'https://images.unsplash.com/photo-1595225476474-87563907a212?auto=format&fit=crop&w=800&q=80', 'Electronics']
    ];
    
    $insertStmt = $pdo->prepare("INSERT INTO products (name, description, price, image_url, category) VALUES (?, ?, ?, ?, ?)");
    foreach ($products as $p) {
        $insertStmt->execute($p);
    }

    // Seed realistic ratings for each product using dummy session IDs
    // product_id => [ [session_id, rating], ... ]
    $seedRatings = [
        1 => [['seed_s1',5],['seed_s2',5],['seed_s3',4],['seed_s4',5],['seed_s5',4],['seed_s6',5],['seed_s7',4],['seed_s8',5],['seed_s9',5],['seed_s10',4],['seed_s11',5],['seed_s12',4],['seed_s13',5],['seed_s14',5],['seed_s15',4],['seed_s16',5],['seed_s17',5],['seed_s18',4],['seed_s19',5],['seed_s20',5],['seed_s21',4],['seed_s22',5],['seed_s23',5],['seed_s24',4],['seed_s25',5],['seed_s26',5],['seed_s27',4],['seed_s28',5],['seed_s29',5],['seed_s30',4],['seed_s31',5],['seed_s32',5],['seed_s33',4],['seed_s34',5],['seed_s35',5],['seed_s36',4],['seed_s37',5],['seed_s38',5],['seed_s39',4],['seed_s40',5],['seed_s41',5],['seed_s42',4],['seed_s43',5],['seed_s44',5],['seed_s45',4],['seed_s46',5],['seed_s47',5],['seed_s48',4],['seed_s49',5],['seed_s50',5],['seed_s51',4],['seed_s52',5],['seed_s53',5],['seed_s54',4],['seed_s55',5],['seed_s56',5],['seed_s57',4],['seed_s58',5],['seed_s59',5],['seed_s60',4],['seed_s61',5],['seed_s62',5],['seed_s63',4],['seed_s64',5],['seed_s65',5],['seed_s66',4],['seed_s67',5],['seed_s68',5],['seed_s69',4],['seed_s70',5],['seed_s71',5],['seed_s72',4],['seed_s73',5],['seed_s74',5],['seed_s75',4],['seed_s76',5],['seed_s77',5],['seed_s78',4],['seed_s79',5],['seed_s80',5],['seed_s81',4],['seed_s82',5],['seed_s83',5],['seed_s84',4],['seed_s85',5],['seed_s86',5],['seed_s87',4],['seed_s88',5],['seed_s89',5],['seed_s90',4],['seed_s91',5],['seed_s92',5],['seed_s93',4],['seed_s94',5],['seed_s95',5],['seed_s96',4],['seed_s97',5],['seed_s98',5],['seed_s99',4],['seed_s100',5],['seed_s101',5],['seed_s102',4],['seed_s103',5],['seed_s104',5],['seed_s105',4],['seed_s106',5],['seed_s107',5],['seed_s108',4],['seed_s109',5],['seed_s110',5],['seed_s111',4],['seed_s112',5],['seed_s113',5],['seed_s114',4],['seed_s115',5],['seed_s116',5],['seed_s117',4],['seed_s118',5],['seed_s119',5],['seed_s120',4],['seed_s121',5],['seed_s122',5],['seed_s123',4],['seed_s124',5],['seed_s125',5],['seed_s126',4],['seed_s127',5],['seed_s128',5],['seed_s129',4],['seed_s130',5],['seed_s131',5],['seed_s132',4],['seed_s133',5],['seed_s134',5],['seed_s135',4],['seed_s136',5],['seed_s137',5],['seed_s138',4],['seed_s139',5],['seed_s140',5],['seed_s141',4],['seed_s142',5],['seed_s143',5],['seed_s144',4],['seed_s145',5],['seed_s146',5],['seed_s147',4],['seed_s148',5],['seed_s149',5],['seed_s150',4]],
        2 => [['seed_t1',5],['seed_t2',4],['seed_t3',5],['seed_t4',4],['seed_t5',5],['seed_t6',4],['seed_t7',5],['seed_t8',4],['seed_t9',5],['seed_t10',4],['seed_t11',5],['seed_t12',4],['seed_t13',5],['seed_t14',4],['seed_t15',5],['seed_t16',4],['seed_t17',5],['seed_t18',4],['seed_t19',5],['seed_t20',4],['seed_t21',5],['seed_t22',4],['seed_t23',5],['seed_t24',4],['seed_t25',5],['seed_t26',4],['seed_t27',5],['seed_t28',4],['seed_t29',5],['seed_t30',4],['seed_t31',5],['seed_t32',4],['seed_t33',5],['seed_t34',4],['seed_t35',5],['seed_t36',4],['seed_t37',5],['seed_t38',4],['seed_t39',5],['seed_t40',4],['seed_t41',5],['seed_t42',4],['seed_t43',5],['seed_t44',4],['seed_t45',5],['seed_t46',4],['seed_t47',5],['seed_t48',4],['seed_t49',5],['seed_t50',4],['seed_t51',5],['seed_t52',4],['seed_t53',5],['seed_t54',4],['seed_t55',5],['seed_t56',4],['seed_t57',5],['seed_t58',4],['seed_t59',5],['seed_t60',4],['seed_t61',5],['seed_t62',4],['seed_t63',5],['seed_t64',4],['seed_t65',5],['seed_t66',4],['seed_t67',5],['seed_t68',4],['seed_t69',5],['seed_t70',4],['seed_t71',5],['seed_t72',4],['seed_t73',5],['seed_t74',4],['seed_t75',5],['seed_t76',4],['seed_t77',5],['seed_t78',4],['seed_t79',5],['seed_t80',4],['seed_t81',5],['seed_t82',4],['seed_t83',5],['seed_t84',4],['seed_t85',5],['seed_t86',4],['seed_t87',5],['seed_t88',4],['seed_t89',5],['seed_t90',4]],
        3 => [['seed_u1',4],['seed_u2',4],['seed_u3',5],['seed_u4',4],['seed_u5',3],['seed_u6',4],['seed_u7',5],['seed_u8',4],['seed_u9',4],['seed_u10',3],['seed_u11',4],['seed_u12',5],['seed_u13',4],['seed_u14',4],['seed_u15',3],['seed_u16',4],['seed_u17',5],['seed_u18',4],['seed_u19',4],['seed_u20',3],['seed_u21',4],['seed_u22',5],['seed_u23',4],['seed_u24',4],['seed_u25',3],['seed_u26',4],['seed_u27',5],['seed_u28',4],['seed_u29',4],['seed_u30',3],['seed_u31',4],['seed_u32',5],['seed_u33',4],['seed_u34',4],['seed_u35',3],['seed_u36',4],['seed_u37',5],['seed_u38',4],['seed_u39',4],['seed_u40',3],['seed_u41',4],['seed_u42',5],['seed_u43',4],['seed_u44',4],['seed_u45',3],['seed_u46',4],['seed_u47',5],['seed_u48',4],['seed_u49',4],['seed_u50',3],['seed_u51',4],['seed_u52',5],['seed_u53',4],['seed_u54',4],['seed_u55',3],['seed_u56',4],['seed_u57',5],['seed_u58',4],['seed_u59',4],['seed_u60',3],['seed_u61',4],['seed_u62',5],['seed_u63',4],['seed_u64',4],['seed_u65',3]],
        4 => [['seed_v1',5],['seed_v2',5],['seed_v3',5],['seed_v4',4],['seed_v5',5],['seed_v6',5],['seed_v7',5],['seed_v8',4],['seed_v9',5],['seed_v10',5],['seed_v11',5],['seed_v12',4],['seed_v13',5],['seed_v14',5],['seed_v15',5],['seed_v16',4],['seed_v17',5],['seed_v18',5],['seed_v19',5],['seed_v20',4],['seed_v21',5],['seed_v22',5],['seed_v23',5],['seed_v24',4],['seed_v25',5],['seed_v26',5],['seed_v27',5],['seed_v28',4],['seed_v29',5],['seed_v30',5],['seed_v31',5],['seed_v32',4],['seed_v33',5],['seed_v34',5],['seed_v35',5],['seed_v36',4],['seed_v37',5],['seed_v38',5],['seed_v39',5],['seed_v40',4],['seed_v41',5],['seed_v42',5],['seed_v43',5],['seed_v44',4],['seed_v45',5],['seed_v46',5],['seed_v47',5],['seed_v48',4],['seed_v49',5],['seed_v50',5],['seed_v51',5],['seed_v52',4],['seed_v53',5],['seed_v54',5],['seed_v55',5],['seed_v56',4],['seed_v57',5],['seed_v58',5],['seed_v59',5],['seed_v60',4],['seed_v61',5],['seed_v62',5],['seed_v63',5],['seed_v64',4],['seed_v65',5],['seed_v66',5],['seed_v67',5],['seed_v68',4],['seed_v69',5],['seed_v70',5],['seed_v71',5],['seed_v72',4],['seed_v73',5],['seed_v74',5],['seed_v75',5],['seed_v76',4],['seed_v77',5],['seed_v78',5],['seed_v79',5],['seed_v80',4],['seed_v81',5],['seed_v82',5],['seed_v83',5],['seed_v84',4],['seed_v85',5],['seed_v86',5],['seed_v87',5],['seed_v88',4],['seed_v89',5],['seed_v90',5],['seed_v91',5],['seed_v92',4],['seed_v93',5],['seed_v94',5],['seed_v95',5],['seed_v96',4],['seed_v97',5],['seed_v98',5],['seed_v99',5],['seed_v100',4],['seed_v101',5],['seed_v102',5],['seed_v103',5],['seed_v104',4],['seed_v105',5],['seed_v106',5],['seed_v107',5],['seed_v108',4],['seed_v109',5],['seed_v110',5],['seed_v111',5],['seed_v112',4],['seed_v113',5],['seed_v114',5],['seed_v115',5],['seed_v116',4],['seed_v117',5],['seed_v118',5],['seed_v119',5],['seed_v120',4]],
        5 => [['seed_w1',4],['seed_w2',5],['seed_w3',4],['seed_w4',4],['seed_w5',5],['seed_w6',4],['seed_w7',4],['seed_w8',5],['seed_w9',4],['seed_w10',4],['seed_w11',5],['seed_w12',4],['seed_w13',4],['seed_w14',5],['seed_w15',4],['seed_w16',4],['seed_w17',5],['seed_w18',4],['seed_w19',4],['seed_w20',5],['seed_w21',4],['seed_w22',4],['seed_w23',5],['seed_w24',4],['seed_w25',4],['seed_w26',5],['seed_w27',4],['seed_w28',4],['seed_w29',5],['seed_w30',4],['seed_w31',4],['seed_w32',5],['seed_w33',4],['seed_w34',4],['seed_w35',5],['seed_w36',4],['seed_w37',4],['seed_w38',5],['seed_w39',4],['seed_w40',4],['seed_w41',5],['seed_w42',4],['seed_w43',4],['seed_w44',5],['seed_w45',4],['seed_w46',4],['seed_w47',5],['seed_w48',4],['seed_w49',4],['seed_w50',5],['seed_w51',4],['seed_w52',4],['seed_w53',5],['seed_w54',4],['seed_w55',4],['seed_w56',5],['seed_w57',4],['seed_w58',4],['seed_w59',5],['seed_w60',4],['seed_w61',4],['seed_w62',5],['seed_w63',4],['seed_w64',4],['seed_w65',5],['seed_w66',4],['seed_w67',4],['seed_w68',5],['seed_w69',4],['seed_w70',4],['seed_w71',5],['seed_w72',4],['seed_w73',4],['seed_w74',5],['seed_w75',4],['seed_w76',4],['seed_w77',5],['seed_w78',4],['seed_w79',4],['seed_w80',5]],
        6 => [['seed_x1',5],['seed_x2',4],['seed_x3',5],['seed_x4',5],['seed_x5',4],['seed_x6',5],['seed_x7',5],['seed_x8',4],['seed_x9',5],['seed_x10',5],['seed_x11',4],['seed_x12',5],['seed_x13',5],['seed_x14',4],['seed_x15',5],['seed_x16',5],['seed_x17',4],['seed_x18',5],['seed_x19',5],['seed_x20',4],['seed_x21',5],['seed_x22',5],['seed_x23',4],['seed_x24',5],['seed_x25',5],['seed_x26',4],['seed_x27',5],['seed_x28',5],['seed_x29',4],['seed_x30',5],['seed_x31',5],['seed_x32',4],['seed_x33',5],['seed_x34',5],['seed_x35',4],['seed_x36',5],['seed_x37',5],['seed_x38',4],['seed_x39',5],['seed_x40',5],['seed_x41',4],['seed_x42',5],['seed_x43',5],['seed_x44',4],['seed_x45',5],['seed_x46',5],['seed_x47',4],['seed_x48',5],['seed_x49',5],['seed_x50',4],['seed_x51',5],['seed_x52',5],['seed_x53',4],['seed_x54',5],['seed_x55',5],['seed_x56',4],['seed_x57',5],['seed_x58',5],['seed_x59',4],['seed_x60',5],['seed_x61',5],['seed_x62',4],['seed_x63',5],['seed_x64',5],['seed_x65',4],['seed_x66',5],['seed_x67',5],['seed_x68',4],['seed_x69',5],['seed_x70',5],['seed_x71',4],['seed_x72',5],['seed_x73',5],['seed_x74',4],['seed_x75',5],['seed_x76',5],['seed_x77',4],['seed_x78',5],['seed_x79',5],['seed_x80',4],['seed_x81',5],['seed_x82',5],['seed_x83',4],['seed_x84',5],['seed_x85',5],['seed_x86',4],['seed_x87',5],['seed_x88',5],['seed_x89',4],['seed_x90',5],['seed_x91',5],['seed_x92',4],['seed_x93',5],['seed_x94',5],['seed_x95',4],['seed_x96',5],['seed_x97',5],['seed_x98',4],['seed_x99',5],['seed_x100',5],['seed_x101',4],['seed_x102',5],['seed_x103',5],['seed_x104',4],['seed_x105',5]]
    ];

    $ratingStmt = $pdo->prepare("INSERT IGNORE INTO ratings (product_id, session_id, rating) VALUES (?, ?, ?)");
    foreach ($seedRatings as $productId => $entries) {
        foreach ($entries as [$sid, $r]) {
            $ratingStmt->execute([$productId, $sid, $r]);
        }
    }

    echo "<h1>✅ SUCCESS: Database Setup Complete!</h1>";
    echo "<p>Products seeded with realistic ratings.</p>";
    echo "<p><a href='/ecommerce/'>Click here to return to the website</a></p>";

} catch(PDOException $e) {
    echo "<h1>❌ Setup failed</h1><p>" . $e->getMessage() . "</p>";
}
?>
