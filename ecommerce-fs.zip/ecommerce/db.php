<?php
$host = '127.0.0.1';
$user = 'root';
$pass = '';

function getDbConnection($dbname = null) {
    global $host, $user, $pass;
    $dsn = "mysql:host=$host;charset=utf8mb4";
    if ($dbname) {
        $dsn .= ";dbname=$dbname";
    }
    try {
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch(PDOException $e) {
        die(json_encode(["success" => false, "error" => "DB Connection failed: " . $e->getMessage()]));
    }
}
?>
