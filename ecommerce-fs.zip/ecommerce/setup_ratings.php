<?php
require_once 'db.php';
try {
    $pdo = getDbConnection('ecommerce_db');

    // Create ratings table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS ratings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        session_id VARCHAR(100) NOT NULL,
        rating TINYINT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY session_product_rating (session_id, product_id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");

    // Check how many products exist
    $count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    if ($count == 0) {
        echo "<h1>⚠️ No products found.</h1><p>Please run <a href='/ecommerce/setup.php'>setup.php</a> first.</p>";
        exit;
    }

    // Seed realistic ratings using INSERT IGNORE (safe to re-run)
    $seedData = [
        // product 1: ~150 ratings, avg ~4.7
        1 => array_merge(
            array_map(fn($i) => ["seed_p1_$i", 5], range(1, 100)),
            array_map(fn($i) => ["seed_p1_b$i", 4], range(1, 50))
        ),
        // product 2: ~90 ratings, avg ~4.5
        2 => array_merge(
            array_map(fn($i) => ["seed_p2_$i", 5], range(1, 45)),
            array_map(fn($i) => ["seed_p2_b$i", 4], range(1, 45))
        ),
        // product 3: ~65 ratings, avg ~4.1
        3 => array_merge(
            array_map(fn($i) => ["seed_p3_$i", 5], range(1, 20)),
            array_map(fn($i) => ["seed_p3_b$i", 4], range(1, 35)),
            array_map(fn($i) => ["seed_p3_c$i", 3], range(1, 10))
        ),
        // product 4: ~120 ratings, avg ~4.8
        4 => array_merge(
            array_map(fn($i) => ["seed_p4_$i", 5], range(1, 90)),
            array_map(fn($i) => ["seed_p4_b$i", 4], range(1, 30))
        ),
        // product 5: ~80 ratings, avg ~4.4
        5 => array_merge(
            array_map(fn($i) => ["seed_p5_$i", 5], range(1, 35)),
            array_map(fn($i) => ["seed_p5_b$i", 4], range(1, 45))
        ),
        // product 6: ~105 ratings, avg ~4.7
        6 => array_merge(
            array_map(fn($i) => ["seed_p6_$i", 5], range(1, 70)),
            array_map(fn($i) => ["seed_p6_b$i", 4], range(1, 35))
        ),
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO ratings (product_id, session_id, rating) VALUES (?, ?, ?)");
    $total = 0;
    foreach ($seedData as $productId => $entries) {
        foreach ($entries as [$sid, $r]) {
            $stmt->execute([$productId, $sid, $r]);
            $total++;
        }
    }

    echo "<h1>✅ Ratings seeded successfully!</h1>";
    echo "<p>Inserted up to $total rating entries across 6 products.</p>";
    echo "<p><a href='/ecommerce/'>Return to website</a></p>";

} catch(PDOException $e) {
    echo "<h1>❌ Failed</h1><p>" . $e->getMessage() . "</p>";
}
?>
