<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

try {
    $pdo = getDbConnection('ecommerce_db');
    $method = $_SERVER['REQUEST_METHOD'];
    $endpoint = $_GET['endpoint'] ?? '';
    $action = $_GET['action'] ?? '';
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Auth Endpoint
    if ($endpoint === 'auth') {
        if ($method === 'POST' && $action === 'register') {
            $username = $input['username'] ?? '';
            $email = $input['email'] ?? '';
            $password = $input['password'] ?? '';
            if (!$username || !$email || !$password) { echo json_encode(["success" => false, "error" => "All fields required"]); exit; }
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) { echo json_encode(["success" => false, "error" => "Email already registered"]); exit; }
            $hash = $password;
            $ins = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $ins->execute([$username, $email, $hash]);
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            echo json_encode(["success" => true, "user" => ["username" => $username, "email" => $email]]); exit;
        }
        if ($method === 'POST' && $action === 'login') {
            $email = $input['email'] ?? '';
            $password = $input['password'] ?? '';
            $stmt = $pdo->prepare("SELECT id, username, password FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $valid = false;
            if ($user) {
                // Support both plain text and bcrypt hashed passwords
                if (password_verify($password, $user['password'])) {
                    $valid = true;
                } elseif ($user['password'] === $password) {
                    $valid = true;
                }
            }
            if ($valid) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $email;
                echo json_encode(["success" => true, "user" => ["username" => $user['username'], "email" => $email]]);
            } else {
                echo json_encode(["success" => false, "error" => "Invalid credentials"]);
            }
            exit;
        }
        if ($method === 'POST' && $action === 'logout') {
            session_destroy(); echo json_encode(["success" => true]); exit;
        }
        if ($method === 'GET' && $action === 'me') {
            if (isset($_SESSION['user_id'])) { echo json_encode(["success" => true, "user" => ["username" => $_SESSION['username'], "email" => $_SESSION['email']]]); }
            else { echo json_encode(["success" => false, "error" => "Not logged in"]); }
            exit;
        }
        echo json_encode(["success" => false, "error" => "Invalid auth action"]); exit;
    }
    
    // Products Endpoint
    if ($endpoint === 'products') {
        if ($method === 'GET') {
            $stmt = $pdo->query("SELECT * FROM products");
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(["success" => true, "data" => $products]);
            exit;
        }
    }
    
    // Cart Endpoint
    if ($endpoint === 'cart') {
        $sessionId = session_id();
        if ($method === 'GET') {
            $stmt = $pdo->prepare("SELECT c.id as cart_id, c.product_id, c.quantity, p.name, p.price, p.image_url FROM cart_items c JOIN products p ON c.product_id = p.id WHERE c.session_id = ?");
            $stmt->execute([$sessionId]);
            echo json_encode(["success" => true, "data" => $stmt->fetchAll(PDO::FETCH_ASSOC)]); exit;
        }
        if ($method === 'POST') {
            if (!isset($input['product_id'])) { echo json_encode(["success" => false, "error" => "Product ID required"]); exit; }
            $productId = (int)$input['product_id'];
            $qtyChange = isset($input['quantity']) ? (int)$input['quantity'] : 1;
            
            $check = $pdo->prepare("SELECT quantity FROM cart_items WHERE session_id = ? AND product_id = ?");
            $check->execute([$sessionId, $productId]);
            if ($row = $check->fetch(PDO::FETCH_ASSOC)) {
                $newQty = $row['quantity'] + $qtyChange;
                if ($newQty <= 0) {
                    $del = $pdo->prepare("DELETE FROM cart_items WHERE session_id = ? AND product_id = ?");
                    $del->execute([$sessionId, $productId]);
                } else {
                    $upd = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE session_id = ? AND product_id = ?");
                    $upd->execute([$newQty, $sessionId, $productId]);
                }
            } else {
                if ($qtyChange > 0) {
                    $ins = $pdo->prepare("INSERT INTO cart_items (session_id, product_id, quantity) VALUES (?, ?, ?)");
                    $ins->execute([$sessionId, $productId, $qtyChange]);
                }
            }
            echo json_encode(["success" => true]); exit;
        }
        if ($method === 'DELETE') {
            $del = $pdo->prepare("DELETE FROM cart_items WHERE session_id = ?");
            $del->execute([$sessionId]);
            echo json_encode(["success" => true]); exit;
        }
    }
    
    // Orders Endpoint
    if ($endpoint === 'orders') {
        if ($method === 'GET') {
            if (!isset($_SESSION['user_id'])) { echo json_encode(["success" => false, "error" => "Not logged in"]); exit; }
            $email = $_SESSION['email'];
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE customer_email = ? ORDER BY created_at DESC");
            $stmt->execute([$email]);
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($orders as &$order) {
                $iStmt = $pdo->prepare("SELECT oi.quantity, oi.price, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
                $iStmt->execute([$order['id']]);
                $order['items'] = $iStmt->fetchAll(PDO::FETCH_ASSOC);
            }
            echo json_encode(["success" => true, "data" => $orders]); exit;
        }
    }

    // Ratings Endpoint
    if ($endpoint === 'ratings') {
        if ($method === 'GET') {
            $productId = (int)($_GET['product_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as count FROM ratings WHERE product_id = ?");
            $stmt->execute([$productId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode(["success" => true, "avg" => round((float)$row['avg_rating'], 1), "count" => (int)$row['count']]); exit;
        }
        if ($method === 'POST') {
            $productId = (int)($input['product_id'] ?? 0);
            $rating = (int)($input['rating'] ?? 0);
            if ($productId < 1 || $rating < 1 || $rating > 5) { echo json_encode(["success" => false, "error" => "Invalid rating"]); exit; }
            $sessionId = session_id();
            $check = $pdo->prepare("SELECT id FROM ratings WHERE product_id = ? AND session_id = ?");
            $check->execute([$productId, $sessionId]);
            if ($check->fetch()) {
                $upd = $pdo->prepare("UPDATE ratings SET rating = ? WHERE product_id = ? AND session_id = ?");
                $upd->execute([$rating, $productId, $sessionId]);
            } else {
                $ins = $pdo->prepare("INSERT INTO ratings (product_id, session_id, rating) VALUES (?, ?, ?)");
                $ins->execute([$productId, $sessionId, $rating]);
            }
            $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as count FROM ratings WHERE product_id = ?");
            $stmt->execute([$productId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode(["success" => true, "avg" => round((float)$row['avg_rating'], 1), "count" => (int)$row['count']]); exit;
        }
    }

    // Checkout Endpoint
    if ($endpoint === 'checkout') {
        $sessionId = session_id();
        if ($method !== 'POST') { echo json_encode(["success" => false, "error" => "Invalid method"]); exit; }
        $name = $input['name'] ?? ''; $email = $input['email'] ?? ''; $address = $input['address'] ?? '';
        $paymentMethod = $input['payment_method'] ?? 'Credit/Debit Card';
        
        if (!$name || !$email || !$address) { echo json_encode(["success" => false, "error" => "All fields are required"]); exit; }
        
        $stmt = $pdo->prepare("SELECT c.product_id, c.quantity, p.price FROM cart_items c JOIN products p ON c.product_id = p.id WHERE c.session_id = ?");
        $stmt->execute([$sessionId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($items) === 0) { echo json_encode(["success" => false, "error" => "Cart is empty"]); exit; }
        
        $totalAmount = 0; foreach ($items as $item) { $totalAmount += $item['price'] * $item['quantity']; }
        
        $pdo->beginTransaction();
        $orderStmt = $pdo->prepare("INSERT INTO orders (customer_name, customer_email, customer_address, total_amount, payment_method) VALUES (?, ?, ?, ?, ?)");
        $orderStmt->execute([$name, $email, $address, $totalAmount, $paymentMethod]);
        $orderId = $pdo->lastInsertId();
        
        $itemStmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        foreach ($items as $item) { $itemStmt->execute([$orderId, $item['product_id'], $item['quantity'], $item['price']]); }
        
        $del = $pdo->prepare("DELETE FROM cart_items WHERE session_id = ?"); $del->execute([$sessionId]);
        $pdo->commit();
        echo json_encode(["success" => true, "order_id" => $orderId, "message" => "Payment successful. Order has been recorded."]); exit;
    }
    
    echo json_encode(["success" => false, "error" => "Invalid endpoint"]);
} catch(Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
    echo json_encode(["success" => false, "error" => "API Error: " . $e->getMessage()]);
}
?>
